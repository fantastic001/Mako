
class ReportGenerator(object):
    
    def __init__(self, projects):
        self.projects = projects

    def generate(self):
        """
        This method should return Report instance 
        """
        pass

    def getProjects(self):
        return self.projects
